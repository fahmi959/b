# coding: utf-8


class Telegram(object):

    def __init__(self):
        print('coming soon...')
